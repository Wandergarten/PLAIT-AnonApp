# PLAIT - AnonApp

for execution, just type 

```{r}
# install.packages('digest')
# install.packages('shiny')
# install.packages('shinyjs')
# install.packages('shinyFeedback')
# install.packages('shinyFiles')
library(digest)
library(shiny)
library(shinyjs)
library(shinyFeedback)
library(shinyFiles)
library(Rcpp)

list.of.packages <- c("digest", "shiny", "shinyjs", "shinyFeedback", "shinyFiles", "Rcpp", "fs")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)


shiny::runGitHub("PLAITAnonApp", "Wandergarten", subdir = "R")
```
Note that this is a student project! 
Please submit feedback to Prof. Ultsch / Dr. MC Thrun @ Databionics Working Group at University of Marburg, Germany: databionics@informatik.uni-marburg.de

Contributors and authors: 
F. Lerch, J. Schulz-Marner, A. Rathert, C. Kujath, S. Nguyen
